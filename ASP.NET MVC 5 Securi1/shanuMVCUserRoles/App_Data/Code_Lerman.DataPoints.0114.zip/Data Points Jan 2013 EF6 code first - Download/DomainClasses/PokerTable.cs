﻿
namespace DomainClasses
{
    public class PokerTable
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public string SerialNo { get; set; }
    }
}
