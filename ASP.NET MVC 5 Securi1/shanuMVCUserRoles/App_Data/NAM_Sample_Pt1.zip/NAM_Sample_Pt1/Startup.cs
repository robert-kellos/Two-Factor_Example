﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(NAM_Sample_Pt1.Startup))]
namespace NAM_Sample_Pt1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
