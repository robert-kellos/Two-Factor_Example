*******************************************************************************
This solution accompanies the January 2014 MSDN Magazine Data Points column
Code First Goodies in Entity Framework 6

 by Julie Lerman
msdn.com/magazine


Julie Lerman
thedatafarm.com/blog
learnentityframework.com
twitter.com/julielerman
pluralsight.com/training/Authors/Details/julie-lerman